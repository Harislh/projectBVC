import "./Header.css";

function Footer() {
  return (
    <footer>
      <h3>All Rights Reserved@2026</h3>
    </footer>
  );
}

export default Footer;

import "./Header.css";
import { Link } from "react-router-dom";
function Header() {
  return (
    <div className="Header">
      <div className="Logo">This is Header.jsx</div>
      <div className="QuickLinks">
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/about">About</Link>
          </li>
          <li>Career</li>
          <li>Help</li>
          <li>More</li>
        </ul>
      </div>
    </div>
  );
}

export default Header;

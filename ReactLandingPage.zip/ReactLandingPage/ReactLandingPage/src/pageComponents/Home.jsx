function Home() {
  return (
    <div>
      <img src="./src/assets/blackAndWhite.jpg" alt="Error Loading" />
    </div>
  );
}
export default Home;
